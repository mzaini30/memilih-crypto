# Ready-made Svelte Templates

## Build

Builds for web apps and Chrome extensions:

```bash
npm run build
```

Builds for Android apps:

```bash
npm run build:android
```

[chat developer](https://wa.me/6281545143654)
